# TwinGrid MCP

An [MCP](https://modelcontextprotocol.io) server that lets **any AI client — Claude, ChatGPT, or anything that speaks MCP — interview you and help fill out your TwinGrid**: a structured identity for an AI clone of you, held as a grid of 19 facets and small, inspectable cells.

It hands the model the grid schema, ready-made starter templates, an interview script, and a validator that mirrors the open-source [TwinGrid engine](https://github.com/obsidianrockofthestars/twingrid). The model uses these to produce a valid grid you can paste straight into TwinGrid or run with the engine yourself.

## Tools

| Tool | What it does |
| --- | --- |
| `twingrid_get_schema` | The 19 facets, their kinds, the cells each requires, and what every cell means. Call this first. |
| `twingrid_list_templates` | The built-in starter archetypes (Creator, Operator, Coach, Author, Founder, Support Rep, Analyst, Companion). |
| `twingrid_get_template` | A full starter grid to personalize. |
| `twingrid_get_blank` | An empty 19-facet skeleton to build from scratch. |
| `twingrid_get_interview_prompt` | A ready-to-use script for interviewing the user one question at a time. |
| `twingrid_validate` | Checks a grid against the engine's rules and tells you exactly which cells are still missing before you call it done. |

All tools are read-only. Nothing leaves your machine; the server holds no keys and makes no network calls.

## Install

Requires Python 3.10+.

```bash
git clone https://github.com/obsidianrockofthestars/twingrid
cd twingrid/mcp
pip install -e .
```

That installs a `twingrid-mcp` command. (You can also run it as `python -m twingrid_mcp.server`.)

## Connect it to Claude Desktop

Open your Claude Desktop config file:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

Add TwinGrid under `mcpServers` (create the file if it does not exist):

```json
{
  "mcpServers": {
    "twingrid": {
      "command": "twingrid-mcp"
    }
  }
}
```

If `twingrid-mcp` is not on your PATH, use the full Python invocation instead:

```json
{
  "mcpServers": {
    "twingrid": {
      "command": "python",
      "args": ["-m", "twingrid_mcp.server"]
    }
  }
}
```

Restart Claude Desktop. You will see the TwinGrid tools appear. Then just say: **"Interview me and build my TwinGrid."**

## Connect it to OpenAI / other clients

Any client that supports MCP servers over **stdio** can run it with the command `twingrid-mcp` (or `python -m twingrid_mcp.server`). For the OpenAI Agents SDK, register it as a stdio MCP server pointing at that command. The tools then become available to the model the same way.

## A typical session

1. The model calls `twingrid_get_schema` to learn the structure.
2. It calls `twingrid_get_interview_prompt` (or `twingrid_get_template` to start from an archetype).
3. It interviews you a couple of questions at a time and drafts your cells.
4. It calls `twingrid_validate` until the grid comes back `complete`.
5. You paste the finished grid JSON into [TwinGrid](https://github.com/obsidianrockofthestars/twingrid), or run it with the engine.

## License

MIT.

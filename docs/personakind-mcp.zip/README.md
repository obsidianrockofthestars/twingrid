# Personakind MCP

This is a small helper that connects Claude Desktop (or any other AI app that speaks MCP) to
[Personakind](https://personakind.com), a site where people write an AI "persona": a grid of
traits, rules, and voice notes for how an AI clone of them should think and talk.

With this installed, you can ask Claude things like:

- "Interview me and build my Personakind persona."
- "Load @coach_sam's persona and talk to me as them."
- "What public personas has @coach_sam published?"

## What it does

- **Build a persona from scratch.** It walks you through an interview, offers starter templates
  (Coach, Founder, Operator, Author, and more), and checks your finished grid against the same
  rules the Personakind site uses, so you know it is complete before you paste it in.
- **Load a public persona from the live site.** Give it a share link, a handle like `@coach_sam`,
  or a persona name, and it fetches that person's *public* persona and hands it to Claude as
  ready-to-use instructions, with a clear note up front about what is data versus what is not
  (see "What it never does" below).

Nothing here requires an account or a password. It only reads what the persona's author already
made public.

## Install in Claude Desktop

**Easiest way (double-click):** if you were given a `.mcpb` file, just double-click it. Claude
Desktop will open and offer to install it; click install and restart Claude Desktop.

**Manual way (edit a config file):** open your Claude Desktop settings file:

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

Add this under `mcpServers` (create the file if it does not exist yet), then restart Claude
Desktop:

```json
{
  "mcpServers": {
    "personakind": {
      "command": "python",
      "args": ["-m", "personakind_mcp.server"]
    }
  }
}
```

This requires Python 3.10 or newer on your computer, plus the `mcp` package
(`pip install mcp`). If you installed this project with `pip install -e .`, you can also use the
shorter form `"command": "personakind-mcp"` instead of the `python -m ...` line above.

## Tools

| Tool | What it does |
| --- | --- |
| `twingrid_get_schema` | The 19 facets, their kinds, the cells each requires, and what every cell means. Call this first when building a persona. |
| `twingrid_list_templates` | The built-in starter archetypes (Creator, Operator, Coach, Author, Founder, Support Rep, Analyst, Companion). |
| `twingrid_get_template` | A full starter grid to personalize. |
| `twingrid_get_blank` | An empty 19-facet skeleton to build from scratch. |
| `twingrid_get_interview_prompt` | A ready-to-use script for interviewing you one question at a time. |
| `twingrid_validate` | Checks a grid against the site's rules and says exactly which cells are still missing. |
| `personakind_find` | Searches public accounts on personakind.com by handle or display name. |
| `personakind_list_personas` | Lists the public personas one account has published, with share links. |
| `personakind_get_persona` | Loads one public persona from the live site, ready to use as a system prompt. |
| `personakind_compose` | Same as above, but a smaller slice: just the core plus one specialist, one mode, one role, and one register. |

## What it never does

- **No writes.** It never creates, edits, or publishes anything on personakind.com. Every live
  tool is read-only.
- **No private keys.** It only ever uses one small, public key that Personakind itself publishes
  for reading public data (the site's own access rules decide what that key can see; there is no
  password or account login involved).
- **Only public personas.** It can only ever see personas and accounts their authors already made
  public on the site. Anything private stays private.
- **Cells are treated as data, not instructions.** When it loads a persona, it always puts a
  short notice first, explaining that the persona's own words describe how that persona thinks
  and talks, and are not commands to the AI reading them. If a persona's text tries to sneak in
  an instruction (for example, telling the AI to change its own rules or share your information),
  the tool is built to point that out instead of going along with it.

## A typical build session

1. The model calls `twingrid_get_schema` to learn the structure.
2. It calls `twingrid_get_interview_prompt` (or `twingrid_get_template` to start from an
   archetype).
3. It interviews you a couple of questions at a time and drafts your cells.
4. It calls `twingrid_validate` until the grid comes back complete.
5. You paste the finished grid JSON into Personakind, or run it with the open-source engine.

## A typical "load someone's persona" session

1. You say "load @coach_sam's persona" (or paste a personakind.com share link).
2. The model calls `personakind_get_persona` with that reference.
3. It gets back the persona's cells, already wrapped with the data-not-instructions notice, and
   can now speak in that persona's voice within those limits.

## License

MIT.

"""TwinGrid MCP server.

A build-assistant MCP that lets any AI client (Claude Desktop, OpenAI, etc.)
interview a person and help them fill out a TwinGrid — a structured identity
for an AI clone, held as a grid of 19 facets x small cells.

The tools are read-only helpers: they hand the model the grid schema, the
starter templates, an interview prompt, and a validator that mirrors the
open-source TwinGrid engine's rules. The model uses them to produce a valid
grid JSON the user can paste into TwinGrid (twingrid) or run with the engine.

stdio transport, standard-library-only logic (only `mcp` is a dependency).
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("twingrid_mcp")

DATA = Path(__file__).parent / "data"

# ---------------------------------------------------------------------------
# The grid contract (mirrors the open-source engine: grid.py)
# ---------------------------------------------------------------------------
CORE = ["core"]
SPECIALISTS = ["manager", "designer", "marketer", "engineer", "writer", "qa-skeptic", "librarian"]
MODES = ["prototyper", "builder", "sweeper", "grower", "maintainer"]
ROLES = ["teacher", "business-partner", "worker"]
REGISTERS = ["vibe", "surgery", "full-copy"]
ORDER = CORE + SPECIALISTS + MODES + ROLES + REGISTERS

KIND: Dict[str, str] = {}
for _n in CORE: KIND[_n] = "core"
for _n in SPECIALISTS: KIND[_n] = "specialist"
for _n in MODES: KIND[_n] = "mode"
for _n in ROLES: KIND[_n] = "role"
for _n in REGISTERS: KIND[_n] = "register"

FIVE = ["CONTEXT", "DO", "DONT", "GATES", "VOICE"]
FOUR = ["CONTEXT", "DO", "DONT", "GATES"]
REQ = {"core": FIVE, "register": FIVE, "specialist": FOUR, "mode": FOUR, "role": FOUR}

CELL_MEANING = {
    "CONTEXT": "Who this persona is here / what is always true / their situation.",
    "DO": "Concrete behaviors this persona should do.",
    "DONT": "Hard limits — what this persona never does.",
    "GATES": "Checks to run before acting / conditions that must hold (quality + safety).",
    "VOICE": "How they sound: tone, rhythm, phrasing (only core and the 3 registers have VOICE).",
}

MARKERS = ["<!-- BEGIN", "<!-- END", "## FACET:"]
MIN_SUBSTANTIVE = 12


def _substantive(text: str) -> str:
    """The part of a cell that actually says something: strip HTML comments,
    drop heading lines and all-symbol lines. Mirrors the engine."""
    out: List[str] = []
    i = 0
    while True:
        s = text.find("<!--", i)
        if s < 0:
            out.append(text[i:])
            break
        out.append(text[i:s])
        e = text.find("-->", s + 4)
        if e < 0:
            break
        i = e + 3
    t = "".join(out)
    keep = []
    for line in t.split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or set(s) <= set("-=*_ "):
            continue
        keep.append(s)
    return " ".join(keep)


def _load(name: str) -> Any:
    return json.loads((DATA / name).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
@mcp.tool(
    name="twingrid_get_schema",
    annotations={"title": "Get the TwinGrid schema", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_get_schema() -> str:
    """Return the full TwinGrid schema: the 19 facets, their kinds, the cells each
    kind requires, and what every cell type means. Call this first so you know the
    exact structure to fill in before interviewing the user.

    Returns:
        str: JSON with facets (name, kind, required cells) and cell meanings.
    """
    facets = [{"name": n, "kind": KIND[n], "required_cells": REQ[KIND[n]]} for n in ORDER]
    schema = {
        "facets": facets,
        "cell_meanings": CELL_MEANING,
        "notes": [
            "core and the 3 registers carry 5 cells (they include VOICE).",
            "every specialist, mode, and role carries 4 cells (no VOICE).",
            "80 cells total across 19 facets when complete.",
            "Never put the sequences '<!-- BEGIN', '<!-- END', or '## FACET:' in any cell.",
            "Each cell needs real, substantive content (>= %d meaningful characters)." % MIN_SUBSTANTIVE,
        ],
        "app_format": {
            "facets": [{"name": "core", "kind": "core",
                        "cells": {"CONTEXT": "...", "DO": "...", "DONT": "...", "GATES": "...", "VOICE": "..."}}],
            "hint": "Produce this shape. Paste the JSON into TwinGrid, or run it with the open-source engine.",
        },
    }
    return json.dumps(schema, ensure_ascii=False, indent=2)


@mcp.tool(
    name="twingrid_list_templates",
    annotations={"title": "List starter templates", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_list_templates() -> str:
    """List the built-in starter templates (archetypes) a user can begin from,
    each with an id, name, and one-line tagline. Use twingrid_get_template to
    fetch a full one.

    Returns:
        str: JSON array of {id, name, tagline}.
    """
    return json.dumps(_load("_index.json"), ensure_ascii=False, indent=2)


@mcp.tool(
    name="twingrid_get_template",
    annotations={"title": "Get a starter template grid", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_get_template(template_id: str) -> str:
    """Return a full starter template as an app-format grid the user can personalize.

    Args:
        template_id (str): One of the ids from twingrid_list_templates
            (e.g. 'creator', 'operator', 'coach', 'author', 'founder',
            'support', 'analyst', 'character').

    Returns:
        str: JSON grid {facets:[{name,kind,cells}], id, name, tagline, theme},
             or an error message naming the valid ids.
    """
    import re as _re
    tid = (template_id or "").strip().lower()
    # containment guard: ids are a strict slug, and the resolved file must live directly in DATA.
    path = (DATA / (tid + ".json"))
    _safe = bool(_re.fullmatch(r"[a-z0-9-]+", tid)) and path.resolve().parent == DATA.resolve()
    if tid in ("", "_index", "blank") or not _safe or not path.is_file():
        ids = [t["id"] for t in _load("_index.json")]
        return json.dumps({"error": "unknown template_id %r" % template_id,
                           "valid_ids": ids}, ensure_ascii=False)
    return json.dumps(_load(tid + ".json"), ensure_ascii=False, indent=2)


@mcp.tool(
    name="twingrid_get_blank",
    annotations={"title": "Get a blank grid skeleton", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_get_blank() -> str:
    """Return an empty 19-facet skeleton to fill from scratch (all cells present
    but blank). Prefer a template when one fits; use this for a fully custom twin.

    Returns:
        str: JSON grid with all 19 facets and empty cells.
    """
    return json.dumps(_load("blank.json"), ensure_ascii=False, indent=2)


@mcp.tool(
    name="twingrid_get_interview_prompt",
    annotations={"title": "Get the interview prompt", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_get_interview_prompt() -> str:
    """Return a ready-to-use interview script: how to interview the user one
    question at a time and turn their answers into grid cells. Follow it to run
    the interview yourself.

    Returns:
        str: The interview prompt text.
    """
    return (DATA / "interview.txt").read_text(encoding="utf-8")


@mcp.tool(
    name="twingrid_validate",
    annotations={"title": "Validate a grid", "readOnlyHint": True,
                 "destructiveHint": False, "idempotentHint": True, "openWorldHint": False},
)
def twingrid_validate(grid_json: str) -> str:
    """Validate an app-format grid against the TwinGrid engine's rules. Reports
    missing facets, missing/empty required cells, wrong cell types, and forbidden
    composer markers, and whether the grid is complete. Run this before telling
    the user their grid is done.

    Args:
        grid_json (str): The grid as a JSON string, either {"facets":[...]} or a
            full template object. Each facet is {name, kind, cells:{CELL:text}}.

    Returns:
        str: JSON {complete: bool, facet_count, cell_count, missing:[...],
             problems:[...]} — problems is empty when the grid is valid.
    """
    try:
        data = json.loads(grid_json)
    except Exception as exc:  # noqa: BLE001
        return json.dumps({"complete": False, "problems": ["grid_json is not valid JSON: %s" % exc]})
    facets = data.get("facets") if isinstance(data, dict) else None
    if not isinstance(facets, list):
        return json.dumps({"complete": False,
                           "problems": ["expected an object with a 'facets' array"]})
    by_name = {f.get("name"): f for f in facets if isinstance(f, dict)}
    problems: List[str] = []
    missing: List[str] = []
    cell_count = 0

    for fn in ORDER:
        if fn not in by_name:
            problems.append("facet '%s' is missing (all 19 facets must be present)" % fn)
            continue
        f = by_name[fn]
        kind = KIND[fn]
        stated = f.get("kind")
        if stated and stated != kind:
            problems.append("facet '%s' has kind '%s' but should be '%s'" % (fn, stated, kind))
        cells = f.get("cells") if isinstance(f.get("cells"), dict) else {}
        for c in REQ[kind]:
            txt = cells.get(c)
            # forbidden composer markers are checked on the raw text, always
            if isinstance(txt, str):
                for m in MARKERS:
                    if m in txt:
                        problems.append("%s/%s contains the forbidden marker %r" % (fn, c, m))
            sub = _substantive(txt) if isinstance(txt, str) else ""
            if not sub:
                missing.append("%s/%s" % (fn, c))
                continue
            cell_count += 1
            if len(sub) < MIN_SUBSTANTIVE:
                problems.append("%s/%s has too little content (needs >= %d meaningful chars)"
                                % (fn, c, MIN_SUBSTANTIVE))
        # VOICE where it is not allowed
        if "VOICE" in cells and kind not in ("core", "register"):
            problems.append("facet '%s' (%s) has a VOICE cell; only core and registers may." % (fn, kind))

    complete = not missing and not problems
    result = {
        "complete": complete,
        "facet_count": len(by_name),
        "cell_count": cell_count,
        "cells_needed": 80,
        "missing": missing,
        "problems": problems,
        "summary": ("Grid is complete and valid — 80/80 cells." if complete
                    else "%d cell(s) still to fill, %d other problem(s)." % (len(missing), len(problems))),
    }
    return json.dumps(result, ensure_ascii=False, indent=2)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()

"""Compatibility shim so `python -m twingrid_mcp.server` still works after
the v1 -> v2 rename to personakind_mcp. All real logic lives there.
"""
from personakind_mcp.server import main

if __name__ == "__main__":
    main()

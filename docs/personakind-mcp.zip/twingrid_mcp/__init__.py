"""Compatibility shim: `twingrid_mcp` re-exports the personakind_mcp entry
point so old integrations that run `python -m twingrid_mcp.server` (or
import `twingrid_mcp.main`) keep working unchanged after the v1 -> v2 rename.
"""
from personakind_mcp.server import main

__all__ = ["main"]

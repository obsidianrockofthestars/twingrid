"""TwinGrid MCP — a build-assistant for filling out a TwinGrid identity."""
from .server import main

__all__ = ["main"]

"""Personakind MCP -- a build assistant plus read-only live persona access."""
from .server import main

__all__ = ["main"]

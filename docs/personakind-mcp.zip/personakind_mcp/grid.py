"""Grid schema, constants, and validator shared by the build-assistant tools.

This module mirrors the open-source Personakind (formerly TwinGrid) engine's
rules exactly as v1 did. It is pure logic with no network access: everything
here is safe to call from a test with no mocking at all.
"""
from __future__ import annotations

import json
import re as _re
from pathlib import Path
from typing import Any, Dict, List

DATA = Path(__file__).parent / "data"

# ---------------------------------------------------------------------------
# The grid contract (mirrors the open-source engine: grid.py)
# ---------------------------------------------------------------------------
CORE = ["core"]
SPECIALISTS = ["manager", "designer", "marketer", "engineer", "writer", "qa-skeptic", "librarian"]
MODES = ["prototyper", "builder", "sweeper", "grower", "maintainer"]
ROLES = ["teacher", "business-partner", "worker"]
REGISTERS = ["vibe", "surgery", "full-copy"]
ORDER = CORE + SPECIALISTS + MODES + ROLES + REGISTERS

KIND: Dict[str, str] = {}
for _n in CORE: KIND[_n] = "core"
for _n in SPECIALISTS: KIND[_n] = "specialist"
for _n in MODES: KIND[_n] = "mode"
for _n in ROLES: KIND[_n] = "role"
for _n in REGISTERS: KIND[_n] = "register"

FIVE = ["CONTEXT", "DO", "DONT", "GATES", "VOICE"]
FOUR = ["CONTEXT", "DO", "DONT", "GATES"]
REQ = {"core": FIVE, "register": FIVE, "specialist": FOUR, "mode": FOUR, "role": FOUR}

CELL_MEANING = {
    "CONTEXT": "Who this persona is here / what is always true / their situation.",
    "DO": "Concrete behaviors this persona should do.",
    "DONT": "Hard limits: what this persona never does.",
    "GATES": "Checks to run before acting / conditions that must hold (quality + safety).",
    "VOICE": "How they sound: tone, rhythm, phrasing (only core and the 3 registers have VOICE).",
}

MARKERS = ["<!-- BEGIN", "<!-- END", "## FACET:"]
MIN_SUBSTANTIVE = 12


def substantive(text: str) -> str:
    """The part of a cell that actually says something: strip HTML comments,
    drop heading lines and all-symbol lines. Mirrors the engine."""
    out: List[str] = []
    i = 0
    while True:
        s = text.find("<!--", i)
        if s < 0:
            out.append(text[i:])
            break
        out.append(text[i:s])
        e = text.find("-->", s + 4)
        if e < 0:
            break
        i = e + 3
    t = "".join(out)
    keep = []
    for line in t.split("\n"):
        s = line.strip()
        if not s or s.startswith("#") or set(s) <= set("-=*_ "):
            continue
        keep.append(s)
    return " ".join(keep)


def load_data(name: str) -> Any:
    return json.loads((DATA / name).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# The six v1 tool bodies, unchanged. server.py's tools call these directly so
# the byte-for-byte output is identical to v1 for identical input.
# ---------------------------------------------------------------------------
def get_schema() -> str:
    facets = [{"name": n, "kind": KIND[n], "required_cells": REQ[KIND[n]]} for n in ORDER]
    schema = {
        "facets": facets,
        "cell_meanings": CELL_MEANING,
        "notes": [
            "core and the 3 registers carry 5 cells (they include VOICE).",
            "every specialist, mode, and role carries 4 cells (no VOICE).",
            "80 cells total across 19 facets when complete.",
            "Never put the sequences '<!-- BEGIN', '<!-- END', or '## FACET:' in any cell.",
            "Each cell needs real, substantive content (>= %d meaningful characters)." % MIN_SUBSTANTIVE,
        ],
        "app_format": {
            "facets": [{"name": "core", "kind": "core",
                        "cells": {"CONTEXT": "...", "DO": "...", "DONT": "...", "GATES": "...", "VOICE": "..."}}],
            "hint": "Produce this shape. Paste the JSON into TwinGrid, or run it with the open-source engine.",
        },
    }
    return json.dumps(schema, ensure_ascii=False, indent=2)


def list_templates() -> str:
    return json.dumps(load_data("_index.json"), ensure_ascii=False, indent=2)


def get_template(template_id: str) -> str:
    tid = (template_id or "").strip().lower()
    # containment guard: ids are a strict slug, and the resolved file must live directly in DATA.
    path = (DATA / (tid + ".json"))
    _safe = bool(_re.fullmatch(r"[a-z0-9-]+", tid)) and path.resolve().parent == DATA.resolve()
    if tid in ("", "_index", "blank") or not _safe or not path.is_file():
        ids = [t["id"] for t in load_data("_index.json")]
        return json.dumps({"error": "unknown template_id %r" % template_id,
                           "valid_ids": ids}, ensure_ascii=False)
    return json.dumps(load_data(tid + ".json"), ensure_ascii=False, indent=2)


def get_blank() -> str:
    return json.dumps(load_data("blank.json"), ensure_ascii=False, indent=2)


def get_interview_prompt() -> str:
    return (DATA / "interview.txt").read_text(encoding="utf-8")


def validate(grid_json: str) -> str:
    try:
        data = json.loads(grid_json)
    except Exception as exc:  # noqa: BLE001
        return json.dumps({"complete": False, "problems": ["grid_json is not valid JSON: %s" % exc]})
    facets = data.get("facets") if isinstance(data, dict) else None
    if not isinstance(facets, list):
        return json.dumps({"complete": False,
                           "problems": ["expected an object with a 'facets' array"]})
    by_name = {f.get("name"): f for f in facets if isinstance(f, dict)}
    problems: List[str] = []
    missing: List[str] = []
    cell_count = 0

    for fn in ORDER:
        if fn not in by_name:
            problems.append("facet '%s' is missing (all 19 facets must be present)" % fn)
            continue
        f = by_name[fn]
        kind = KIND[fn]
        stated = f.get("kind")
        if stated and stated != kind:
            problems.append("facet '%s' has kind '%s' but should be '%s'" % (fn, stated, kind))
        cells = f.get("cells") if isinstance(f.get("cells"), dict) else {}
        for c in REQ[kind]:
            txt = cells.get(c)
            # forbidden composer markers are checked on the raw text, always
            if isinstance(txt, str):
                for m in MARKERS:
                    if m in txt:
                        problems.append("%s/%s contains the forbidden marker %r" % (fn, c, m))
            sub = substantive(txt) if isinstance(txt, str) else ""
            if not sub:
                missing.append("%s/%s" % (fn, c))
                continue
            cell_count += 1
            if len(sub) < MIN_SUBSTANTIVE:
                problems.append("%s/%s has too little content (needs >= %d meaningful chars)"
                                % (fn, c, MIN_SUBSTANTIVE))
        # VOICE where it is not allowed
        if "VOICE" in cells and kind not in ("core", "register"):
            problems.append("facet '%s' (%s) has a VOICE cell; only core and registers may." % (fn, kind))

    complete = not missing and not problems
    result = {
        "complete": complete,
        "facet_count": len(by_name),
        "cell_count": cell_count,
        "cells_needed": 80,
        "missing": missing,
        "problems": problems,
        "summary": ("Grid is complete and valid, 80/80 cells." if complete
                    else "%d cell(s) still to fill, %d other problem(s)." % (len(missing), len(problems))),
    }
    return json.dumps(result, ensure_ascii=False, indent=2)
